package fakarava.ecosystem;

public abstract interface Clock {
    public abstract void ticktock();
}
